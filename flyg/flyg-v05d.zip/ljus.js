// Ljus och bildkänsla: filmisk tonmappning, miljöljus från himlen så att plåt, glas och metall får riktiga reflexer,
// riktiga skuggor från solen på planet och marken, samt ett finkornigt detaljmönster på marken nära planet.
// Allt går att slå av i config.json "grafik" om telefonen blir varm. Inget här ändrar spelets fysik eller styrning.
export function riggaLjus(THREE, renderer, scene, sun, mark, G) {
  const G2 = G || {};
  // 1) Tonmappning: ACES ger mjuka högdagrar och fylligare färg än rå utmatning.
  if (G2.tonmappning !== false) { renderer.toneMapping = THREE.ACESFilmicToneMapping; renderer.toneMappingExposure = G2.exponering ?? 1.0; }

  // 2) Miljöljus: en liten himmel renderas en gång till en PMREM-karta. Den används av alla PBR-material i planet.
  if (G2.miljoljus !== false) {
    const pm = new THREE.PMREMGenerator(renderer);
    const mini = new THREE.Scene();
    const skyMat = new THREE.ShaderMaterial({
      side: THREE.BackSide,
      uniforms: { top: { value: new THREE.Color(G2.himmel_topp ?? 0x3f78b4) }, hor: { value: new THREE.Color(G2.himmel_horisont ?? 0xc9d6dc) }, mark: { value: new THREE.Color(G2.mark_farg ?? 0x5a6a44) }, sol: { value: new THREE.Vector3().copy(sun.position).normalize() } },
      vertexShader: 'varying vec3 vD; void main(){ vD = normalize(position); gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }',
      fragmentShader: `uniform vec3 top, hor, mark, sol; varying vec3 vD;
        void main(){ float h = vD.y; vec3 c = h > 0.0 ? mix(hor, top, smoothstep(0.0, 0.5, h)) : mix(hor, mark, smoothstep(0.0, -0.3, h));
          float s = max(dot(normalize(vD), sol), 0.0); c += vec3(1.0, 0.92, 0.78) * (pow(s, 600.0) * 40.0 + pow(s, 8.0) * 0.35);
          gl_FragColor = vec4(c, 1.0); }`
    });
    mini.add(new THREE.Mesh(new THREE.SphereGeometry(50, 32, 16), skyMat));
    scene.environment = pm.fromScene(mini, 0.04).texture;
    pm.dispose();
  }

  // 3) Skuggor: en liten ortografisk solskugga som följer planet. Bara planet kastar, marken tar emot.
  let skuggor = null;
  if (G2.skuggor !== false) {
    renderer.shadowMap.enabled = true; renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    sun.castShadow = true; const r = G2.skugg_radie_m ?? 22;
    sun.shadow.mapSize.set(G2.skugg_px ?? 1024, G2.skugg_px ?? 1024);
    sun.shadow.camera.left = -r; sun.shadow.camera.right = r; sun.shadow.camera.top = r; sun.shadow.camera.bottom = -r;
    sun.shadow.camera.near = 1; sun.shadow.camera.far = 4000; sun.shadow.bias = -0.0004; sun.shadow.normalBias = 0.6;
    const malpunkt = new THREE.Object3D(); scene.add(malpunkt); sun.target = malpunkt;
    mark.ground.receiveShadow = true;
    const riktning = new THREE.Vector3().copy(sun.position).normalize();
    skuggor = {
      /** Flytta skuggkameran så att planet alltid ligger i mitten av skuggkartan. */
      folj(pos) { malpunkt.position.copy(pos); sun.position.copy(pos).addScaledVector(riktning, 900); },
      /** Markera en modell som skuggkastare. */
      kastare(root) { root.traverse(o => { if (o.isMesh) { o.castShadow = true; o.receiveShadow = false; } }); }
    };
  }

  // 4) Detaljmönster på marken: ett brusmönster multipliceras in i markfärgen nära kameran, så gräset inte är en platt yta.
  if (G2.markdetalj !== false && mark.ground) {
    const N = 256, c = document.createElement('canvas'); c.width = c.height = N; const x = c.getContext('2d');
    const img = x.createImageData(N, N), d = img.data; let seed = 11;
    const rnd = () => (seed = (seed * 16807) % 2147483647) / 2147483647;
    for (let i = 0; i < N * N; i++) { const v = 150 + rnd() * 105; d[i * 4] = d[i * 4 + 1] = d[i * 4 + 2] = v; d[i * 4 + 3] = 255; }
    x.putImageData(img, 0, 0);
    // mjuka till bruset en aning så det blir fläckar i stället för korn
    x.globalAlpha = 0.5; x.filter = 'blur(1px)'; x.drawImage(c, 0, 0); x.filter = 'none'; x.globalAlpha = 1;
    const tex = new THREE.CanvasTexture(c); tex.wrapS = tex.wrapT = THREE.RepeatWrapping; tex.anisotropy = 4; tex.colorSpace = THREE.NoColorSpace;
    const rep = G2.markdetalj_upprepning ?? 420, styrka = G2.markdetalj_styrka ?? 0.35;
    const m = mark.ground.material;
    m.onBeforeCompile = sh => {
      sh.uniforms.detalj = { value: tex }; sh.uniforms.detaljRep = { value: rep }; sh.uniforms.detaljStyrka = { value: styrka };
      sh.fragmentShader = sh.fragmentShader
        .replace('#include <common>', '#include <common>\nuniform sampler2D detalj; uniform float detaljRep; uniform float detaljStyrka;')
        .replace('#include <map_fragment>', '#include <map_fragment>\n#ifdef USE_MAP\n float dn = texture2D(detalj, vMapUv * detaljRep).r; diffuseColor.rgb *= mix(1.0, dn * 1.6, detaljStyrka);\n#endif');
    };
    m.needsUpdate = true;
  }
  return { skuggor };
}
